package servicio;
import interfaces.CSVSerializable;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.*;
import java.util.function.Consumer;
import java.util.function.Predicate;
import modelo.Categoria;
import modelo.Libro;

public class Inventario<T extends CSVSerializable & Comparable<T>> {
    private List<T> elementos;

    public Inventario() {
        this.elementos = new ArrayList<>();
    }

    public List<T> getElementos() {
        return elementos;
    }
    
    
    public void mostrarElementos(List<T> lista) {
    for (T item : lista) {
        System.out.println(item);
    }
}

    public void agregar(T elemento) {
        elementos.add(elemento);
    }

    public void eliminar(T elemento) {
        elementos.remove(elemento);
    }

    public T obtener(int indice) {
        return elementos.get(indice);
    }

    public List<T> filtrar(Predicate<? super T> criterio) {
        List<T> filtrados = new ArrayList<>();
        for (T elemento : elementos) {
            if (criterio.test(elemento)) {
                filtrados.add(elemento);
            }
        }
        return filtrados;
    }

    public List<T> ordenarPorNatural() {
        List<T> copia = new ArrayList<>(elementos);
        Collections.sort(copia); // orden natural 
        return copia;
    }

    public List<T> ordenarPor(Comparator<? super T> comparator) {
        List<T> copia = new ArrayList<>(elementos);
        copia.sort(comparator); // orden personalizado 
        return copia;
    }
    public int tamanio() {
        return elementos.size();
    }
    
   // Dentro de la clase Inventario
    public void paraCadaElemento(Consumer<Libro> accion) {
        for (T item : elementos) {
            accion.accept((Libro) item);
        }
    }

     public static void guardarEmpleadosCSV(List<? extends Libro> lista, String path){
    
        File archivo = new File(path);   
    try{
        if(archivo.exists()){
            System.out.println(" el puto arhivo ya existe");
        }else{
        archivo.createNewFile();
        }
    
    }catch(IOException ex){
        System.out.println("ocurruio un eerro acl crear el archivo");
    }
    
    
    try(BufferedWriter bw = new BufferedWriter( new FileWriter(archivo))){
       
       for (Libro libro : lista) {          
        bw.write(libro.toCSV() + "\n"); // Uso del objeto 'libro' para invocar el método no estático
    }

      
        
    }
    
    catch(IOException ex){
        System.out.println("ocurruio un eerro acl crear el archivo");
    }
    }
   // aca deberia de cambiar la list
    public static List<Libro> cargarEmpleadosCSV(String path){
       List<Libro> toReturn = new ArrayList<>();
        try (BufferedReader bf =  new BufferedReader(new FileReader(path))) {
            String linea;
            //si no te lee 1 añado el bf.redlie
            while((linea = bf.readLine()) != null){
               if (linea.endsWith("\n")){
                    linea = linea.substring(linea.length()-1);
               } 
               String[] data = linea.split(",");
               if (data.length == 4){
                int id = Integer.parseInt(data[0]);
                String titulo = data[1];
                String autor = data[2];
                Categoria categoria = Categoria.valueOf(data[3]);
                Libro libro = new Libro(id, titulo, autor, categoria);
                toReturn.add(libro);

               }
            }
     
        } catch (IOException ex) {
            System.out.println("error maestro");
        }
    
         return toReturn;
    }
    
      public static void serializarEmpleados(List<? extends Libro> lista, String path){
    try (FileOutputStream archivo = new FileOutputStream(path);
            ObjectOutputStream salida = new ObjectOutputStream (archivo){
    
    }){  
        salida.writeObject(lista);
        
    }
    catch (IOException ex ){
        ex.printStackTrace();
    }
    }
    public static List<Libro> deserializar(String path) throws ClassNotFoundException{
        List<Libro> toReturn = new ArrayList<>();
        
        try(ObjectInputStream input = new ObjectInputStream(new FileInputStream(path))){
        toReturn = (List<Libro>)input.readObject();
        
    } catch(IOException ex ) {
        ex.printStackTrace();
    }
        return toReturn;
    
    }
}
    
    
    

