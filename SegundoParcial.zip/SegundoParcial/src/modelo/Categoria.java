
package modelo;

public enum Categoria {
    CIENCIA, 
    LITERATURA, 
    TECNOLOGIA,
    ARTE, 
    HISTORIA,
    ENTRETENIMIENTO
    
}
