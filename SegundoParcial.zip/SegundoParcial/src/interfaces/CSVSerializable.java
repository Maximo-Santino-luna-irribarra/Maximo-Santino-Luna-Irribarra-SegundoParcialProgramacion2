
package interfaces;

@FunctionalInterface
public interface CSVSerializable {
    String toCSV(); // Exportar datos en formato CSV
}
